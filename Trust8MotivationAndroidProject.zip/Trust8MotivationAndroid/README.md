# Trust8Motivation Android app starter

This is an Android WebView app project for https://trust8motivation.blogspot.com/2018/09/home.html.
It is not a compiled APK yet. It needs to be built using Android SDK/Gradle (the included GitHub Actions workflow can do this in the cloud).

## Build using an Android phone
1. Sign in to GitHub in your phone browser and create a new repository.
2. Upload the contents of this ZIP to the repository (not the ZIP file itself).
3. Open the repository's Actions tab and enable Actions if asked.
4. Choose "Build Trust8Motivation APK" and tap "Run workflow".
5. When the workflow finishes, open the run and download the `Trust8Motivation-debug-apk` artifact.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`, then open it on your Android phone and allow installation from that source if Android asks.

## Notes
- This is a simple internet-connected WebView wrapper. The website needs internet access.
- The app currently opens your existing Blogger page; it does not apply the new website theme to Blogger.
- This is a debug APK for testing, not a Play Store release. A release build should use a private signing key and be tested before distribution.
- Never share your Google password or GitHub credentials in chat.
